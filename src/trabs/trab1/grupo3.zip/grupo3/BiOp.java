package trabs.trab1.grupo3;

public abstract class BiOp implements Exp{
    private Exp left;
    private Exp right;
    public char operator;

    protected BiOp ( Exp left, Exp right, char operator){
        this.left = left;
        this.right = right;
        this.operator = operator;
    }

    public int evaluate() throws InvalidExpExcepion{
        return operate(left.evaluate(), right.evaluate());
    }

    protected abstract int operate(int v1, int v2);

    @Override
    public String toString() {
        return left + String.valueOf(operator) + right;
    }
}