package trabs.trab1.grupo3;

public class Const extends Elem{
}
