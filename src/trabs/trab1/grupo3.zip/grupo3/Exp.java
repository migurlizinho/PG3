package trabs.trab1.grupo3;

public interface Exp {
    int evaluate();
    int getPriority();
    String toString();
}