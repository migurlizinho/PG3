package trabs.trab1.grupo3;

public class Var extends Elem{
}
