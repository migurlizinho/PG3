package aulasLEIRT31D.excecoes;

public class DivideByZeroException extends RuntimeException {
	public DivideByZeroException() {
		super("Divide by zero");
	}
	public DivideByZeroException(String msg) {
		super( msg );
	}
}
