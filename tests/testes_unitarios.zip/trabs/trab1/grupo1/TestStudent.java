package trabs.trab1.grupo1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestStudent {
   @Test
    public void testConstructsThreeArg( ) {
        Student s = new Student(120, "Maria", 10);
        assertEquals(120, s.getNumber());
        assertEquals("Maria", s.getName());
        assertEquals(10, s.getGrade());
    }

    @Test
    public void testConstructsTwoArg( ) {
        Student s1 = new Student("Manuel", 10);
        Student s2 = new Student("Pedro", 15);

        assertEquals(1, s1.getNumber());
        assertEquals("Manuel", s1.getName());
        assertEquals(10, s1.getGrade());

        assertEquals(2, s2.getNumber());
        assertEquals("Pedro", s2.getName());
        assertEquals(15, s2.getGrade());
    }

    @Test
    public void testIsApproved() {
       assertFalse(new Student(1, "Maria", 9).isApproved());
       assertTrue(new Student(1, "Maria", 10).isApproved());
       assertTrue(new Student(1, "Maria", 11).isApproved());
    }

    @Test
    public void testEquals( ) {
        Student t1 = new Student(123,"Maria",16);
        assertTrue(t1.equals(t1));
        assertTrue(t1.equals(new Student(123,"Maria",16)));
        assertTrue(t1.equals(new Student(123, new String("Maria"),16)));
        assertFalse(t1.equals(new Student(123,"Maria",18)));
        assertFalse(t1.equals(new Student(123,"Manuel",16)));
        assertFalse(t1.equals(new Student(125, "Maria",16)));
        assertFalse( t1.equals( null));
        assertFalse( t1.equals("maria"));
    }



    @Test
    public void testCompareTo( ) {
        Student t1 = new Student(123,"Maria",16);
        assertEquals(0, t1.compareTo(t1));
        assertEquals(0, t1.compareTo(new Student(123,"Maria",16)));
        Student t2 = new Student(124,"Manuel",14);
        assertTrue(t1.compareTo(t2) < 0);
        assertTrue(t2.compareTo(t1) > 0);
    }

    @Test
    public void testToString(){
        assertEquals("123: Maria - 16", new Student(123,"Maria",16).toString());
    }


    @Test
    public void testParseStudent(){
        Student s = Student.parseStudent("125: Maria Silva - 12");
        assertEquals(125, s.getNumber());
        assertEquals("Maria Silva", s.getName());
        assertEquals(12, s.getGrade());
    }


}
