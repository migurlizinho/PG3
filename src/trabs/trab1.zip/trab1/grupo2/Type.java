package trabs.trab1.grupo2;

public interface Type {
   public String getName();
   public int getMinimum();
}