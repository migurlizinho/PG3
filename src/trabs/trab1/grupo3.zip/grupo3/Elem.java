package trabs.trab1.grupo3;

public class Elem implements Exp{
    @Override
    public int evaluate() {
        return 0;
    }

    @Override
    public int getPriority() {
        return 0;
    }
}