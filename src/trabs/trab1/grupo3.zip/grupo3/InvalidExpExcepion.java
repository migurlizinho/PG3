package trabs.trab1.grupo3;

public class InvalidExpExcepion extends RuntimeException {
    public InvalidExpExcepion(String message) {
        super(message);
    }
}
