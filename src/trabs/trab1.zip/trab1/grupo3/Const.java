package trabs.trab1.grupo3;

public class Const extends Elem{
    public Const(int value) {
        super(value);
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
